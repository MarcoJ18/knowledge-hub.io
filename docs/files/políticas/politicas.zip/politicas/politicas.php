<?php
/*
Plugin Name: Páginas Legales Automáticas con Menú Inferior
Plugin URI: https://tusitio.com
Description: Plugin para generar automáticamente páginas de Términos de uso, Aviso legal, Política de cookies y Declaración de accesibilidad web, y añadirlas a un menú inferior con un enlace al Sitemap.
Version: 1.2
Author: Tu Nombre
Author URI: https://tusitio.com
License: GPLv2 or later
*/

if (!defined('ABSPATH')) {
    exit; // Salir si se accede directamente.
}

class Paginas_Legales_Plugin {

    public function __construct() {
        // Hook para crear las páginas cuando se activa el plugin
        register_activation_hook(__FILE__, [$this, 'crear_paginas_legales']);
        // Hook para eliminar el menú al desactivar el plugin (opcional)
        register_deactivation_hook(__FILE__, [$this, 'eliminar_menu']);
    }

    // Función para crear las páginas
    public function crear_paginas_legales() {
        // Datos de las páginas
        $paginas = [
            'terminos-de-uso' => [
                'titulo' => 'Términos de Uso',
                'contenido' => 'Aquí irían los términos de uso de tu sitio web...'
            ],
            'aviso-legal' => [
                'titulo' => 'Aviso Legal',
                'contenido' => 'Aquí iría el aviso legal de tu sitio web...'
            ],
            'politica-de-cookies' => [
                'titulo' => 'Política de Cookies',
                'contenido' => 'Aquí iría la política de cookies de tu sitio web...'
            ],
            'declaracion-accesibilidad' => [
                'titulo' => 'Declaración de Accesibilidad Web',
                'contenido' => 'Aquí iría la declaración de accesibilidad de tu sitio web...'
            ],
        ];

        // Array para almacenar los IDs de las páginas creadas
        $page_ids = [];

        foreach ($paginas as $slug => $pagina) {
            // Verifica si la página ya existe
            if (null == get_page_by_path($slug)) {
                // Crear la página si no existe
                $page_id = wp_insert_post([
                    'post_title' => $pagina['titulo'],
                    'post_content' => $pagina['contenido'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug
                ]);
                // Almacenar el ID de la página
                $page_ids[] = $page_id;
            } else {
                // Si la página ya existe, obtener su ID
                $page = get_page_by_path($slug);
                $page_ids[] = $page->ID;
            }
        }

        // Llamada para crear el menú
        $this->crear_menu_inferior($page_ids);
    }

    // Función para crear un menú inferior
    public function crear_menu_inferior($page_ids) {
        // Verifica si el menú ya existe
        $menu_name = 'menu-inferior';
        $menu_exists = wp_get_nav_menu_object($menu_name);

        if (!$menu_exists) {
            // Si no existe, crea el menú
            $menu_id = wp_create_nav_menu($menu_name);

            // Asigna las páginas creadas al menú
            foreach ($page_ids as $page_id) {
                wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-object-id' => $page_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type',
                    'menu-item-status' => 'publish'
                ]);
            }

            // Agregar enlace personalizado para el Sitemap
            $sitemap_url = site_url('/sitemap_index.xml');
            wp_update_nav_menu_item($menu_id, 0, [
                'menu-item-type' => 'custom',
                'menu-item-url' => $sitemap_url,
                'menu-item-title' => 'Sitemap',
                'menu-item-status' => 'publish'
            ]);

            // Asignar el menú a la ubicación del menú inferior
            $locations = get_theme_mod('nav_menu_locations');
            $locations['footer'] = $menu_id;  // Cambia 'footer' por el slug de la ubicación del menú que usa tu tema
            set_theme_mod('nav_menu_locations', $locations);
        }
    }

    // Función para eliminar el menú cuando se desactiva el plugin (opcional)
    public function eliminar_menu() {
        $menu_name = 'menu-inferior';
        $menu = wp_get_nav_menu_object($menu_name);
        
        if ($menu) {
            wp_delete_nav_menu($menu_name);
        }
    }
}

// Inicializa el plugin
new Paginas_Legales_Plugin();

?>
